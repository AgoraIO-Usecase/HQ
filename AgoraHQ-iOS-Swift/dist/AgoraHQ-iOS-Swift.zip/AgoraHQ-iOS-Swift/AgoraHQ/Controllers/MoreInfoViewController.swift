//
//  MoreInfoViewController.swift
//  AgoraHQ
//
//  Created by ZhangJi on 08/02/2018.
//  Copyright © 2018 ZhangJi. All rights reserved.
//

import UIKit

class MoreInfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.insertSubview(backgroundView, at: 0)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func abc(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
}
