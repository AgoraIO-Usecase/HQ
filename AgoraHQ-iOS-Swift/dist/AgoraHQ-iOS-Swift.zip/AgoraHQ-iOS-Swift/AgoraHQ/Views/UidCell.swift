//
//  UidCell.swift
//  AgoraHQ
//
//  Created by ZhangJi on 06/02/2018.
//  Copyright © 2018 ZhangJi. All rights reserved.
//

import UIKit

class UidCell: UITableViewCell {

    @IBOutlet weak var uidLabel: UILabel!
    @IBOutlet weak var uidImageView: UIImageView!
    
}
