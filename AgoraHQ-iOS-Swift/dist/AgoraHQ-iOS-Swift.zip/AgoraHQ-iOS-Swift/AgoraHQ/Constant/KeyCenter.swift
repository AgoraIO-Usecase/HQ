//
//  KeyCenter.swift
//  AgoraHQ
//
//  Created by ZhangJi on 08/01/2018.
//  Copyright © 2018 ZhangJi. All rights reserved.
//

struct KeyCenter {
    static let AppId: String = "319294c67d174c878cc7922551e6e773"
    // if the App Certificate is not opened, Fill in AppcertificateID with ""
    static let AppcertificateID:  String = ""
}
