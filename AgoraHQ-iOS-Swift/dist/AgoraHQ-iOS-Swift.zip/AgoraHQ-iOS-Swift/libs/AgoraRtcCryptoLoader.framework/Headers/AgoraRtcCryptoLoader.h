//
//  AgoraRtcCryptoLoader.h
//  AgoraRtcCryptoLoader
//
//  Created by junhao wang on 1/5/17.
//  Copyright © 2017 Agora. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AgoraRtcCryptoLoader : NSObject

@end
