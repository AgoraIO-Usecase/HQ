//
//  AppID.swift
//  Agora iOS Tutorial
//
//  Created by James Fang on 7/19/16.
//  Copyright © 2016 Agora.io. All rights reserved.
//

let AppID: String = <#Your App ID#>                  // Tutorial Step 1
