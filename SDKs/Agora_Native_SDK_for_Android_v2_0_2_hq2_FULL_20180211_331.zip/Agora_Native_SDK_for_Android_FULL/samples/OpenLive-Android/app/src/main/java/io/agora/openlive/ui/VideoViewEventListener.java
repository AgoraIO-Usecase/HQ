package io.agora.openlive.ui;

import android.view.View;

public interface VideoViewEventListener {
    void onItemDoubleClick(View v, Object item);
}
